import React, { useState, useEffect } from 'react';
import { BarChart3, TrendingUp, Users, Store, Calendar, DollarSign } from 'lucide-react';
import { Restaurant, Subscription, User } from '../../types';
import { loadFromStorage } from '../../data/mockData';
import { Badge } from '../../components/ui/Badge';

export const SuperAdminAnalytics: React.FC = () => {
  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [users, setUsers] = useState<User[]>([]);

  useEffect(() => {
    const restaurantData = loadFromStorage('restaurants') || [];
    const subscriptionData = loadFromStorage('subscriptions') || [];
    const userData = loadFromStorage('users') || [];
    
    setRestaurants(restaurantData);
    setSubscriptions(subscriptionData);
    setUsers(userData);
  }, []);

  // Calculate analytics
  const totalRestaurants = restaurants.length;
  const activeRestaurants = restaurants.filter(r => r.status === 'active').length;
  const pendingRestaurants = restaurants.filter(r => r.status === 'pending').length;
  const totalUsers = users.length;
  const verifiedUsers = users.filter(u => u.email_verified).length;

  const activeSubscriptions = subscriptions.filter(s => s.status === 'active').length;
  const expiredSubscriptions = subscriptions.filter(s => s.status === 'expired').length;
  const trialSubscriptions = subscriptions.filter(s => s.status === 'trial').length;

  // Monthly registrations
  const getMonthlyRegistrations = () => {
    const monthlyData: { [key: string]: number } = {};
    
    restaurants.forEach(restaurant => {
      const date = new Date(restaurant.created_at);
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      monthlyData[monthKey] = (monthlyData[monthKey] || 0) + 1;
    });

    return Object.entries(monthlyData)
      .sort(([a], [b]) => a.localeCompare(b))
      .slice(-6); // Last 6 months
  };

  const monthlyRegistrations = getMonthlyRegistrations();

  // Plan distribution
  const planDistribution = {
    basic: subscriptions.filter(s => s.plan_type === 'basic').length,
    premium: subscriptions.filter(s => s.plan_type === 'premium').length,
    enterprise: subscriptions.filter(s => s.plan_type === 'enterprise').length,
    trial: subscriptions.filter(s => s.plan_type === 'trial').length,
  };

  // Recent activity
  const recentRestaurants = restaurants
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
    .slice(0, 5);

  const expiringSoon = subscriptions.filter(sub => {
    const endDate = new Date(sub.end_date);
    const now = new Date();
    const daysUntilExpiry = Math.ceil((endDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return daysUntilExpiry <= 7 && daysUntilExpiry > 0;
  });

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Estadísticas del Sistema</h1>
        <div className="text-sm text-gray-500">
          Última actualización: {new Date().toLocaleString()}
        </div>
      </div>

      {/* Main Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center">
            <Store className="h-8 w-8 text-blue-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total Restaurantes</p>
              <p className="text-2xl font-semibold text-gray-900">{totalRestaurants}</p>
            </div>
          </div>
          <div className="mt-2">
            <span className="text-sm text-green-600 font-medium">
              {activeRestaurants} activos
            </span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center">
            <Users className="h-8 w-8 text-green-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total Usuarios</p>
              <p className="text-2xl font-semibold text-gray-900">{totalUsers}</p>
            </div>
          </div>
          <div className="mt-2">
            <span className="text-sm text-green-600 font-medium">
              {verifiedUsers} verificados
            </span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center">
            <DollarSign className="h-8 w-8 text-purple-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Suscripciones Activas</p>
              <p className="text-2xl font-semibold text-gray-900">{activeSubscriptions}</p>
            </div>
          </div>
          <div className="mt-2">
            <span className="text-sm text-red-600 font-medium">
              {expiredSubscriptions} vencidas
            </span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center">
            <TrendingUp className="h-8 w-8 text-orange-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Crecimiento Mensual</p>
              <p className="text-2xl font-semibold text-gray-900">
                {monthlyRegistrations.length > 0 ? monthlyRegistrations[monthlyRegistrations.length - 1][1] : 0}
              </p>
            </div>
          </div>
          <div className="mt-2">
            <span className="text-sm text-purple-600 font-medium">
              Este mes
            </span>
          </div>
        </div>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Registrations */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
            <Calendar className="w-5 h-5 mr-2" />
            Registros por Mes
          </h3>
          <div className="space-y-3">
            {monthlyRegistrations.map(([month, count]) => (
              <div key={month} className="flex items-center justify-between">
                <span className="text-sm text-gray-600">{month}</span>
                <div className="flex items-center">
                  <div className="w-32 bg-gray-200 rounded-full h-2 mr-3">
                    <div 
                      className="bg-blue-600 h-2 rounded-full" 
                      style={{ width: `${(count / Math.max(...monthlyRegistrations.map(([, c]) => c))) * 100}%` }}
                    />
                  </div>
                  <span className="text-sm font-medium text-gray-900">{count}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Plan Distribution */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
            <BarChart3 className="w-5 h-5 mr-2" />
            Distribución de Planes
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Básico</span>
              <div className="flex items-center">
                <div className="w-32 bg-gray-200 rounded-full h-2 mr-3">
                  <div 
                    className="bg-blue-500 h-2 rounded-full" 
                    style={{ width: `${(planDistribution.basic / subscriptions.length) * 100}%` }}
                  />
                </div>
                <span className="text-sm font-medium text-gray-900">{planDistribution.basic}</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Premium</span>
              <div className="flex items-center">
                <div className="w-32 bg-gray-200 rounded-full h-2 mr-3">
                  <div 
                    className="bg-green-500 h-2 rounded-full" 
                    style={{ width: `${(planDistribution.premium / subscriptions.length) * 100}%` }}
                  />
                </div>
                <span className="text-sm font-medium text-gray-900">{planDistribution.premium}</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Enterprise</span>
              <div className="flex items-center">
                <div className="w-32 bg-gray-200 rounded-full h-2 mr-3">
                  <div 
                    className="bg-purple-500 h-2 rounded-full" 
                    style={{ width: `${(planDistribution.enterprise / subscriptions.length) * 100}%` }}
                  />
                </div>
                <span className="text-sm font-medium text-gray-900">{planDistribution.enterprise}</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Prueba</span>
              <div className="flex items-center">
                <div className="w-32 bg-gray-200 rounded-full h-2 mr-3">
                  <div 
                    className="bg-yellow-500 h-2 rounded-full" 
                    style={{ width: `${(planDistribution.trial / subscriptions.length) * 100}%` }}
                  />
                </div>
                <span className="text-sm font-medium text-gray-900">{planDistribution.trial}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity and Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Restaurants */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-medium text-gray-900">Restaurantes Recientes</h3>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {recentRestaurants.map(restaurant => (
                <div key={restaurant.id} className="flex items-center justify-between">
                  <div className="flex items-center">
                    {restaurant.logo && (
                      <img
                        src={restaurant.logo}
                        alt={restaurant.name}
                        className="w-8 h-8 rounded-full object-cover mr-3"
                      />
                    )}
                    <div>
                      <p className="text-sm font-medium text-gray-900">{restaurant.name}</p>
                      <p className="text-xs text-gray-500">
                        {new Date(restaurant.created_at).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <Badge variant={restaurant.status === 'active' ? 'success' : 'warning'}>
                    {restaurant.status === 'active' ? 'Activo' : 'Pendiente'}
                  </Badge>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Expiring Subscriptions */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-medium text-gray-900">Suscripciones por Vencer</h3>
          </div>
          <div className="p-6">
            {expiringSoon.length === 0 ? (
              <p className="text-sm text-gray-500 text-center py-4">
                No hay suscripciones próximas a vencer
              </p>
            ) : (
              <div className="space-y-4">
                {expiringSoon.map(subscription => {
                  const restaurant = restaurants.find(r => r.id === subscription.restaurant_id);
                  const daysLeft = Math.ceil((new Date(subscription.end_date).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
                  
                  return (
                    <div key={subscription.id} className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-900">{restaurant?.name}</p>
                        <p className="text-xs text-gray-500">
                          Vence en {daysLeft} día{daysLeft !== 1 ? 's' : ''}
                        </p>
                      </div>
                      <Badge variant="warning">
                        {subscription.plan_type}
                      </Badge>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};