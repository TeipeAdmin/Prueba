export interface User {
  id: string;
  email: string;
  password: string;
  role: 'restaurant_owner' | 'super_admin';
  created_at: string;
  updated_at: string;
}

export interface Customer {
  name: string;
  phone: string;
  email?: string;
  address?: string;
  delivery_instructions?: string;
}

export interface ProductVariation {
  id: string;
  name: string;
  price: number;
}

export interface ProductIngredient {
  id: string;
  name: string;
  optional: boolean;
  extra_cost?: number;
}

export interface Category {
  id: string;
  name: string;
  description?: string;
  restaurant_id: string;
  order_index: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Product {
  id: string;
  restaurant_id: string;
  category_id: string;
  name: string;
  description: string;
  images: string[];
  variations: ProductVariation[];
  ingredients?: ProductIngredient[];
  dietary_restrictions?: string[];
  spice_level?: number;
  preparation_time?: string;
  status: 'active' | 'inactive';
  sku?: string;
  is_available: boolean;
  is_featured: boolean;
  order_index: number;
  created_at: string;
  updated_at: string;
}

export interface Order {
  id: string;
  restaurant_id: string;
  order_number: string;
  customer: Customer;
  items: OrderItem[];
  order_type: 'pickup' | 'delivery' | 'table';
  delivery_address?: string;
  table_number?: string;
  delivery_cost?: number;
  subtotal: number;
  total: number;
  status: 'pending' | 'confirmed' | 'preparing' | 'ready' | 'delivered' | 'cancelled';
  estimated_time?: string;
  special_instructions?: string;
  created_at: string;
  updated_at: string;
}

export interface OrderItem {
  id: string;
  product_id: string;
  product: Product;
  variation: ProductVariation;
  quantity: number;
  unit_price: number;
  total_price: number;
  selected_ingredients?: ProductIngredient[];
  special_notes?: string;
}

export interface CartItem {
  id: string;
  product: Product;
  variation: ProductVariation;
  quantity: number;
  selectedIngredients: ProductIngredient[];
  specialNotes?: string;
  totalPrice: number;
}

export interface UISettings {
  layout_type: 'cards' | 'grid' | 'list';
  show_search_bar: boolean;
  info_message: string;
}

export interface Theme {
  template: 'modern' | 'elegant' | 'warm' | 'dark' | 'minimal';
  primary_color: string;
  secondary_color: string;
  tertiary_color: string;
  font_family: string;
  button_style: 'rounded' | 'square' | 'pill';
}

export interface SocialMedia {
  facebook?: string;
  instagram?: string;
  twitter?: string;
  whatsapp?: string;
  website?: string;
}

export interface BusinessHours {
  [key: string]: {
    open: string;
    close: string;
    is_open: boolean;
  };
}

export interface DeliverySettings {
  enabled: boolean;
  zones: string[];
  min_order_amount: number;
  estimated_time: string;
  delivery_cost: number;
}

export interface TableOrdersSettings {
  enabled: boolean;
  table_numbers: number;
  qr_codes: boolean;
  auto_assign: boolean;
}

export interface NotificationSettings {
  email: string;
  sound_enabled: boolean;
  whatsapp?: string;
}

export interface RestaurantSettings {
  ui_settings: UISettings;
  theme: Theme;
  social_media: SocialMedia;
  business_hours: BusinessHours;
  delivery: DeliverySettings;
  table_orders: TableOrdersSettings;
  notifications: NotificationSettings;
  currency?: string;
  language?: string;
  timezone?: string;
}

export interface Restaurant {
  id: string;
  name: string;
  slug: string;
  email: string;
  phone?: string;
  address?: string;
  description?: string;
  logo?: string;
  owner_name?: string;
  owner_id: string;
  is_active: boolean;
  settings: RestaurantSettings;
  created_at: string;
  updated_at: string;
}

export interface Subscription {
  id: string;
  restaurant_id: string;
  plan_type: 'free' | 'basic' | 'pro' | 'business';
  status: 'active' | 'inactive' | 'cancelled' | 'expired';
  start_date: string;
  end_date: string;
  auto_renew: boolean;
  created_at: string;
  updated_at: string;
}
export interface PlanFeatures {
  max_products: number;
  max_categories: number;
  analytics: boolean;
  custom_domain: boolean;
  priority_support: boolean;
  advanced_customization: boolean;
}

export interface Plan {
  id: string;
  name: string;
  price: number;
  currency: string;
  billing_period: 'monthly' | 'yearly';
  features: PlanFeatures;
  popular?: boolean;
}
